// ignore_for_file: omit_local_variable_types

import 'package:dart_frog/dart_frog.dart';

import '../../data/mysql_db.dart';
import '../../models/error_model.dart';
import '../../models/data/list_data_model.dart';
import '../../models/user/login.dart';

Future<Response> onRequest(RequestContext context) async {
  try {
    switch (context.request.method) {
      case HttpMethod.get:
        break;
      case HttpMethod.post:
        final bool isSucces = await saveUser(context);
        if (!isSucces) {
          throw ErrorModel.alreadyExistUser().toJson();
        }
        break;
      default:
    }
    return Response.json();
  } catch (e) {
    return Response.json(
      statusCode: 400,
      body: e,
    );
  }
}

Future<Response> onAuthRequest(RequestContext context) async {
  final IDataSourse db = context.read<IDataSourse>();
  final String request = await context.request.body();
  final bool isExists = await db.isExistUser(registerModelFromJson(request));
  if (isExists) {
    return Response(body: {'isAuth': isExists}.toString());
  } else {
    return Response.json(statusCode: 400, body: ErrorModel.notAuth().toJson());
  }
}

Future<bool> saveUser(RequestContext context) async {
  final Request request = context.request;
  final IDataSourse db = context.read<IDataSourse>();
  final String body = await request.body();
  final RegisterModel registerModel = registerModelFromJson(body);
  final bool isRegistred = await db.createUser(registerModel);
  return isRegistred;
}
